const products = [
{
    id: 1,
    name: 'Apple',
    price: 4.95
},
{
    id: 2,
    name: 'Orange',
    price: 3.99
},
{
    id: 3,
    name: 'Kiwifruit',
    price: 2.99
},
{
    id: 4,
    name: 'Advocado',
    price: 3.99
},
{
    id: 5,
    name: 'Pineapple',
    price: 4.50
},
{
    id: 6,
    name: 'Pear',
    price: 3.79
}
];

module.exports = products;

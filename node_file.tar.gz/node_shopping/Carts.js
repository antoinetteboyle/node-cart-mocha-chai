const carts = [
    {
        quantity: 0,
        id: 1,
        name: 'Test',
        price: 0.50,
    }
];

module.exports = carts;
